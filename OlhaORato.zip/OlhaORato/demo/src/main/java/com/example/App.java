package com.example;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import java.util.Random;
import java.io.IOException;

/**
 * JavaFX App
 */
public class App extends Application {


    Stage primaryStage;
    private static Scene scene;

    Random aleatorioImages = new Random();

    int ivIndex = 0;
    ImageView iv = new ImageView();
    
    Button btn = new Button("Próxima");
    Button btn2 = new Button("Aleatório");

    Image[] arrayImages = new Image[]{
                new Image(getClass().getResourceAsStream("/images/mouse.png")),
                new Image(getClass().getResourceAsStream("/images/mouse2.png")),
                new Image(getClass().getResourceAsStream("/images/mouse3.png"))
        };

    @Override
    public void start(Stage stage) throws IOException {

        this.primaryStage = stage;

        iv.setImage(arrayImages[ivIndex]);

        var casaRatinho = new VBox(iv, btn, btn2);

        setup(casaRatinho);
        styles(casaRatinho);

        primaryStage.setScene(new Scene(casaRatinho, 400, 400));
        primaryStage.setResizable(false);
        primaryStage.setTitle("Olha o Rato!");
        primaryStage.getIcons().add(
                new Image(getClass().getResourceAsStream("/images/ratinhofeliz.png"))
        );
        primaryStage.show();

    }

    void setup(VBox casaRatinho){

        iv.setFitWidth(200);
        iv.setFitHeight(200);
        casaRatinho.setSpacing(20);
        casaRatinho.setAlignment(Pos.CENTER);


        btn.setOnAction(e-> btnClick());
        btn2.setOnAction(e->btnRamdonImages());

    }
    void btnClick(){
        ivIndex = (ivIndex + 1) % arrayImages.length;
        iv.setImage(arrayImages[ivIndex]);
    }

    void btnRamdonImages(){
        ivIndex = aleatorioImages.nextInt(arrayImages.length);
        iv.setImage(arrayImages[ivIndex]);
    }
    void styles(VBox casaRatinho){

        casaRatinho.setStyle("""
                            -fx-background-color: #6B1E28;
                            -fx-padding: 20;
                            -fx-spacing: 15;
                            """);

        btn.setStyle("""
                        -fx-background-color: #A88448;
                        -fx-text-fill: #1F3B4D;
                        -fx-font-size: 14px;
                        -fx-padding: 10 20;
                        -fx-background-radius: 20;
                        -fx-font-weight: bold;
                        -fx-cursor: hand;
                        -fx-border-color: #1F3B4D;
                        -fx-border-width: 2;
                        -fx-border-radius: 18;
                        """);

        btn2.setStyle("""
                    -fx-background-color: #1F3B4D;
                    -fx-text-fill: #F2E9D8;
                    -fx-font-size: 14px;
                    -fx-padding: 10 20;
                    -fx-background-radius: 20;
                    -fx-font-weight: bold;
                    -fx-border-color: #A88448;
                    -fx-border-width: 2;
                    -fx-border-radius: 18;
                    -fx-cursor: hand;
                    """);

    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}